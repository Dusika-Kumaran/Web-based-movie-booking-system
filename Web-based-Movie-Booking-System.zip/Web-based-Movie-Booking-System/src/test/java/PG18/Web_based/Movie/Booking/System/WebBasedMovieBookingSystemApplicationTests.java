package PG18.Web_based.Movie.Booking.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebBasedMovieBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
