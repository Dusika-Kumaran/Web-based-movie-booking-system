package com.movieticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebBasedMovieBookingSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebBasedMovieBookingSystemApplication.class, args);
    }
}
